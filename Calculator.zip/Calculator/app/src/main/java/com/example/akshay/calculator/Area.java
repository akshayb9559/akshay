package com.example.akshay.calculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Area extends AppCompatActivity {

    EditText no1, result;
    Button square, circle, prev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.area);

        no1 = findViewById(R.id.no1);
        result = findViewById(R.id.result);

        square = findViewById(R.id.square);
        circle = findViewById(R.id.circle);

        prev = findViewById(R.id.prev);

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Area.this, MainActivity.class);
                startActivity(intent);
                Area.this.finish();

            }
        });

        circle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double a,r;
                if(no1.getText().toString().equals("0")){
                    result.setText("Invalid Input");
                }
                r=Double.parseDouble(no1.getText().toString());
                if(r<0){
                    result.setText("length cannot be negative");
                }
                else{
                  a=3.14*r*r;
                  result.setText(""+a);
                }
            }
        });

        square.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             Double sqr ,a;
             a=Double.parseDouble(no1.getText().toString());
             sqr=a*a;
             result.setText(""+sqr);
            }
        });

    }
}
