package com.example.akshay.calculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText no1, no2, result;
    Button addition, substration, multiplication, division, area;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        no1 = findViewById(R.id.no1);
        no2 = findViewById(R.id.no2);
        result=findViewById(R.id.result);
        addition = findViewById(R.id.addition);
        substration = findViewById(R.id.substraction);
        multiplication = findViewById(R.id.multiplication);
        division = findViewById(R.id.division);
        area = findViewById(R.id.area);

        addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             Double a,b,c;
             if(no1.getText().toString().equals(".")){
                 result.setText("Invalid Input");
             }
             else if(no2.getText().toString().equals(".")){
                 result.setText("Invalid Input");
             }
             else {
                 a = Double.parseDouble(no1.getText().toString());
                 b = Double.parseDouble(no2.getText().toString());
                 c = a + b;
                 result.setText("" + c);
             }
            }
        });


        substration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double a,b,c;
                if(no1.getText().toString().equals(".")|| no1.getText().toString().equals(" ")){
                    result.setText("Invalid Input");
                }
                else if(no2.getText().toString().equals(".")){
                    result.setText("Invalid Input");
                }
                else {
                    a = Double.parseDouble(no1.getText().toString());
                    b = Double.parseDouble(no2.getText().toString());
                    c = a - b;
                    result.setText("" + c);
                }

            }
        });

        multiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double a,b,c;
                if(no1.getText().toString().equals(".")|| no1.getText().toString().equals(" ")){
                    result.setText("Invalid Input");
                }
                else if(no2.getText().toString().equals(".")){
                    result.setText("Invalid Input");
                }
                else {
                    a = Double.parseDouble(no1.getText().toString());
                    b = Double.parseDouble(no2.getText().toString());
                    c = a - b;
                    result.setText("" + c);
                }

            }
        });
        division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double a,b,c;
                if(no1.getText().toString().equals(".")|| no1.getText().toString().equals(" ")){
                    result.setText("Invalid Inputs");
                }
                else if(no2.getText().toString().equals(".")|| no2.getText().toString().equals("0")){
                    result.setText("Invalid Operation");
                }

                else {
                    a = Double.parseDouble(no1.getText().toString());
                    b = Double.parseDouble(no2.getText().toString());
                    c = a - b;
                    result.setText("" + c);
                }

            }
        });


        area.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Area.class);
                startActivity(intent);
                MainActivity.this.finish();
            }
        });
    }
}
